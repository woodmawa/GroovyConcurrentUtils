/*
 * Copyright (c) 2025 the authors of this project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Simple actor system that manages a set of named actors.
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>Create actors</li>
 *   <li>Register externally-created actors</li>
 *   <li>Provide basic router and remote actor factories</li>
 *   <li>Coordinate system-wide shutdown</li>
 * </ul>
 */

package org.softwood.actor

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j

import java.time.Duration
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

@CompileStatic
@Slf4j
class ActorSystem implements AutoCloseable {

    private final String name
    private final Map<String, ScopedValueActor<Object>> actors =
            Collections.synchronizedMap(new LinkedHashMap<>())

    ActorSystem(String name) {
        this.name = name
        log.info("ActorSystem '{}' created", name)
    }

    String getName() { return name }

    void register(ScopedValueActor<Object> actor) {
        actors.put(actor.name, actor)
    }

    ScopedValueActor<Object> createActor(
            String actorName,
            ScopedValueActor.MessageHandler<Object> handler,
            int mailboxSize
    ) {
        ScopedValueActor<Object> a = new ScopedValueActor<Object>(actorName, handler, mailboxSize)
        actors.put(actorName, a)
        return a
    }

    ScopedValueActor<Object> createActor(
            String actorName,
            ScopedValueActor.MessageHandler<Object> handler
    ) {
        return createActor(actorName, handler, 1000)
    }

    RouterActor createRoundRobinRouter(String routerName,
                                       Collection<ScopedValueActor<?>> members) {
        RouterActor router = new RouterActor(routerName, new ArrayList<>(members), RouterStrategy.ROUND_ROBIN)
        actors.put(routerName, (ScopedValueActor<Object>) router)
        return router
    }

    RouterActor createRandomRouter(String routerName,
                                   Collection<ScopedValueActor<?>> members) {
        RouterActor router = new RouterActor(routerName, new ArrayList<>(members), RouterStrategy.RANDOM)
        actors.put(routerName, (ScopedValueActor<Object>) router)
        return router
    }

    RouterActor createBroadcastRouter(String routerName,
                                      Collection<ScopedValueActor<?>> members) {
        RouterActor router = new RouterActor(routerName, new ArrayList<>(members), RouterStrategy.BROADCAST)
        actors.put(routerName, (ScopedValueActor<Object>) router)
        return router
    }

    RemoteActor createRemoteActor(String actorName, String uri) {
        RemoteActor ra = new RemoteActor(actorName, new URI(uri))
        actors.put(actorName, (ScopedValueActor<Object>) ra)
        return ra
    }

    ScopedValueActor<Object> get(String actorName) {
        return actors.get(actorName)
    }

    List<String> actorNames() {
        return new ArrayList<String>(actors.keySet())
    }

    int actorCount() {
        return actors.size()
    }

    void shutdown(Duration timeout) {
        log.info("Shutting down '{}' with {} actors", name, actors.size())
        for (ScopedValueActor<Object> a : actors.values()) {
            try {
                a.stopAndWait(timeout)
            } catch (Throwable t) {
                log.warn("Error shutting down actor '{}': {}", a.name, t.message, t)
            }
        }
        actors.clear()
        log.info("ActorSystem '{}' shutdown complete", name)
    }

    void shutdown() {
        shutdown(Duration.ofSeconds(5))
    }

    @Override
    void close() {
        shutdown()
    }
}