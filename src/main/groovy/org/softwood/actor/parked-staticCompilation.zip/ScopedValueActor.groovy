/*
 * Copyright (c) 2025 the authors of this project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.softwood.actor

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j

import java.time.Duration
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Core virtual-thread-based actor implementation.
 * <p>
 * Each actor:
 * <ul>
 *   <li>Processes messages sequentially from a mailbox</li>
 *   <li>Runs its loop on a dedicated virtual thread</li>
 *   <li>Provides per-message {@link ActorContext} via JDK {@code ScopedValue}</li>
 *   <li>Supports tell / ask / askSync / sendReceive / join</li>
 *   <li>Exposes simple metrics for observability</li>
 * </ul>
 *
 * @param <M> the message type handled by this actor
 */
@CompileStatic
@Slf4j
class ScopedValueActor<M> implements AutoCloseable {

    private static final ScopedValue<ActorContext> ACTOR_CONTEXT =
            ScopedValue.newInstance()

    private final String name
    private final BlockingQueue<Message<M>> mailbox
    private final ExecutorService executor
    private volatile MessageHandler<M> handler

    private volatile boolean running = true
    private final AtomicLong enqueuedCount = new AtomicLong(0)
    private final AtomicLong processedCount = new AtomicLong(0)
    private final AtomicLong failedCount = new AtomicLong(0)
    private final Map<String, Object> state = [:].asSynchronized()
    private Future<?> loopFuture

    private Closure<Throwable> failureListener

    /**
     * Internal message container.
     */
    @CompileStatic
    static final class Message<M> {
        final M payload
        final String sender
        final long timestamp
        final CompletableFuture<Object> replyTo

        Message(M payload, String sender, CompletableFuture<Object> replyTo) {
            this.payload = payload
            this.sender = sender
            this.timestamp = System.currentTimeMillis()
            this.replyTo = replyTo
        }

        @Override
        String toString() {
            "Message(sender=${sender}, ts=${timestamp}, payload=${payload})"
        }
    }

    /**
     * Context visible for the duration of message processing on the actor's virtual thread.
     */
    @CompileStatic
    static final class ActorContext {
        final String actorName
        final Map<String, Object> state
        final long messageNumber

        ActorContext(String actorName, Map<String, Object> state, long messageNumber) {
            this.actorName = actorName
            this.state = state
            this.messageNumber = messageNumber
        }

        Object get(String key) { state.get(key) }
        void set(String key, Object value) { state.put(key, value) }
        boolean has(String key) { state.containsKey(key) }
        void remove(String key) { state.remove(key) }

        @Override
        String toString() {
            "ActorContext(name=${actorName}, msg=${messageNumber}, keys=${state.keySet()})"
        }
    }

    /**
     * Functional interface for message handlers.
     *
     * @param <M> the message type
     */
    @FunctionalInterface
    @CompileStatic
    interface MessageHandler<M> {
        Object handle(M message, ActorContext context)
    }

    /**
     * Construct a new actor with explicit mailbox size.
     */
    ScopedValueActor(String name, MessageHandler<M> handler, int mailboxSize) {
        this.name = name
        this.handler = handler
        this.mailbox = new LinkedBlockingQueue<Message<M>>(mailboxSize)
        this.executor = Executors.newVirtualThreadPerTaskExecutor()
        startMessageLoop()
    }

    /**
     * Construct a new actor with default mailbox size (1000).
     */
    ScopedValueActor(String name, MessageHandler<M> handler) {
        this(name, handler, 1000)
    }

    private void startMessageLoop() {
        loopFuture = executor.submit({ ->
            log.debug("Actor '{}' started on thread {}", name, Thread.currentThread())
            try {
                while (running || !mailbox.isEmpty()) {
                    Message<M> msg = mailbox.poll(100, TimeUnit.MILLISECONDS)
                    if (msg != null) {
                        processMessage(msg)
                    }
                }
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt()
                log.warn("Actor '{}' loop interrupted", name)
            } catch (Throwable t) {
                log.error("Actor '{}' loop crashed: {}", name, t.message, t)
                if (failureListener != null) {
                    failureListener.call(t)
                }
            } finally {
                log.debug("Actor '{}' stopped", name)
            }
        } as Runnable)
    }

    private void processMessage(Message<M> message) {
        long num = enqueuedCount.incrementAndGet()
        ActorContext ctx = new ActorContext(name, state, num)
        AtomicReference<Object> resultRef = new AtomicReference<Object>()

        try {
            Runnable r = { ->
                Object r0 = handler.handle(message.payload, ctx)
                resultRef.set(r0)
            } as Runnable

            ScopedValue.where(ACTOR_CONTEXT, ctx).run(r)

            processedCount.incrementAndGet()
            if (message.replyTo != null) {
                message.replyTo.complete(resultRef.get())
            }

            log.debug("Actor '{}' processed message #{} from '{}'", name, num, message.sender)
        } catch (Throwable t) {
            failedCount.incrementAndGet()
            log.error("Actor '{}' handler error on message #{}: {}", name, num, t.message, t)
            if (message.replyTo != null) {
                message.replyTo.completeExceptionally(t)
            }
            if (failureListener != null) {
                failureListener.call(t)
            }
        }
    }

    // -------------------------------------------------------------------------
    // Messaging API
    // -------------------------------------------------------------------------

    void tell(M message) {
        tell(message, "anonymous")
    }

    void tell(M message, String sender) {
        if (!running) {
            throw new IllegalStateException("Actor '" + name + "' is not running")
        }
        if (!mailbox.offer(new Message<M>(message, sender, null))) {
            throw new IllegalStateException("Actor '" + name + "' mailbox is full")
        }
    }

    CompletableFuture<Object> ask(M message) {
        return ask(message, "anonymous")
    }

    CompletableFuture<Object> ask(M message, String sender) {
        if (!running) {
            throw new IllegalStateException("Actor '" + name + "' is not running")
        }
        CompletableFuture<Object> reply = new CompletableFuture<Object>()
        if (!mailbox.offer(new Message<M>(message, sender, reply))) {
            reply.completeExceptionally(
                    new IllegalStateException("Actor '" + name + "' mailbox is full")
            )
        }
        return reply
    }

    Object askSync(M message) {
        return askSync(message, "anonymous", Duration.ofSeconds(5))
    }

    Object askSync(M message, Duration timeout) {
        return askSync(message, "anonymous", timeout)
    }

    Object askSync(M message, String sender, Duration timeout) {
        return ask(message, sender).get(timeout.toMillis(), TimeUnit.MILLISECONDS)
    }

    Object sendReceive(M message) {
        return askSync(message)
    }

    Object sendReceive(M message, Duration timeout) {
        return askSync(message, timeout)
    }

    ScopedValueActor<M> join() {
        return join(Duration.ofSeconds(10))
    }

    ScopedValueActor<M> join(Duration timeout) {
        stopAndWait(timeout)
        return this
    }

    // -------------------------------------------------------------------------
    // Failure listener and lifecycle
    // -------------------------------------------------------------------------

    void setFailureListener(Closure<Throwable> listener) {
        this.failureListener = listener
    }

    /**
     * Replace the internal handler implementation.
     * Intended for subclasses such as routers or supervisors.
     */
    protected void setInternalHandler(MessageHandler<M> newHandler) {
        this.handler = newHandler
    }

    static boolean isInActorContext() {
        return ACTOR_CONTEXT.isBound()
    }

    static ActorContext getCurrentContext() {
        if (!ACTOR_CONTEXT.isBound()) {
            throw new IllegalStateException("Not in actor context")
        }
        return ACTOR_CONTEXT.get()
    }

    String getName() { return name }

    long getProcessedCount() { return processedCount.get() }
    long getFailedCount()    { return failedCount.get() }
    long getEnqueuedCount()  { return enqueuedCount.get() }
    int  getMailboxSize()    { return mailbox.size() }

    void stop() {
        running = false
    }

    void stopAndWait(Duration timeout) {
        running = false
        try {
            if (loopFuture != null) {
                loopFuture.get(timeout.toMillis(), TimeUnit.MILLISECONDS)
                log.debug("Actor '{}' stopped gracefully", name)
            }
        } catch (TimeoutException te) {
            log.warn("Actor '{}' did not terminate within {} ms", name, timeout.toMillis())
            loopFuture?.cancel(true)
        } catch (Throwable ignored) {
        } finally {
            executor.shutdownNow()
        }
    }

    @Override
    void close() {
        stopAndWait(Duration.ofSeconds(10))
    }

    @Override
    String toString() {
        "Actor[" + name + "](enqueued=" + enqueuedCount.get() +
                ", processed=" + processedCount.get() +
                ", failed=" + failedCount.get() +
                ", mailbox=" + mailbox.size() + ")"
    }
}
