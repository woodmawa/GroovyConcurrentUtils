/*
 * Copyright (c) 2025 the authors of this project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.softwood.actor

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j

import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse

/**
 * Actor that adapts local messages into outbound HTTP requests.
 * <p>
 * Messages are converted to strings via {@code toString()} and POSTed to
 * the configured endpoint. The HTTP response body is returned as the
 * handler result for ask/askSync calls.
 */
@CompileStatic
@Slf4j
class RemoteActor extends ScopedValueActor<Object> {

    private final URI endpoint
    private final HttpClient client

    @CompileStatic
    private static final class RemoteHandler
            implements ScopedValueActor.MessageHandler<Object> {

        private final RemoteActor outer

        RemoteHandler(RemoteActor outer) {
            this.outer = outer
        }

        @Override
        Object handle(Object msg, ScopedValueActor.ActorContext ctx) {
            return outer.sendRemote(msg)
        }
    }

    RemoteActor(String name, URI endpoint) {
        super(name, new RemoteHandler(null), 1000)
        this.endpoint = endpoint
        this.client = HttpClient.newHttpClient()
        this.setInternalHandler(new RemoteHandler(this))
    }

    private Object sendRemote(Object msg) {
        String payload = (msg instanceof String) ? (String) msg : String.valueOf(msg)

        HttpRequest request = HttpRequest.newBuilder(endpoint)
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .header("Content-Type", "text/plain")
                .build()

        try {
            log.debug("RemoteActor '{}' POST to {}: {}", name, endpoint, payload)
            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString())
            log.debug("RemoteActor '{}' got response: {}", name, response.body())
            return response.body()
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt()
            log.warn("RemoteActor '{}' HTTP call failed: {}", name, e.message)
            throw new RuntimeException(
                    "RemoteActor '" + "$name" + "' HTTP call failed", e)
        }
    }

    URI getEndpoint() { return endpoint }
}