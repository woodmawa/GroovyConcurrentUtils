/*
 * Copyright (c) 2025 the authors of this project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.softwood.actor

import groovy.transform.CompileDynamic

/**
 * Small Groovy DSL for building actors.  using compileDynamic
 * <p>
 * Example:
 * <pre>
 * def a = Actors.actor {
 *     name "Printer"
 *     onMessage { msg, ctx -> println msg }
 * }
 * </pre>
 */
@CompileDynamic
final class Actors {

    private Actors() {}

    /**
     * Build a {@link ScopedValueActor} from a DSL specification.
     *
     * @param spec the configuration closure
     * @return a created actor
     */
    static ScopedValueActor<Object> actor(Closure<?> spec) {
        ActorBuilder builder = new ActorBuilder()
        spec.resolveStrategy = Closure.DELEGATE_FIRST
        spec.delegate = builder
        spec.call()
        return builder.build()
    }

    /**
     * Builder supporting the {@code actor { ... }} DSL.
     */
    static final class ActorBuilder {
        String actorName = "actor"
        int mailboxSize = 1000
        ScopedValueActor.MessageHandler<Object> handler

        void name(String n) { this.actorName = n }
        void mailboxSize(int n) { this.mailboxSize = n }

        void onMessage(Closure<?> c) {
            this.handler = wrapHandler(c)
        }

        private static ScopedValueActor.MessageHandler<Object> wrapHandler(Closure<?> c) {
            return { Object msg, ScopedValueActor.ActorContext ctx ->
                c.call(msg, ctx)
            } as ScopedValueActor.MessageHandler<Object>
        }

        ScopedValueActor<Object> build() {
            if (handler == null) {
                throw new IllegalStateException(
                        "Actor '" + actorName + "' is missing onMessage { ... }")
            }
            return new ScopedValueActor<Object>(actorName, handler, mailboxSize)
        }
    }
}