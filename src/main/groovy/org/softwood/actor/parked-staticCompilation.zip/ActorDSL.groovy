package org.softwood.actor

import groovy.transform.CompileDynamic

/**
 * Lightweight actor creation DSL.
 *
 * Usage in tests:
 *     def a = actor(system) {
 *         name "Printer"
 *         onMessage { msg, ctx -> println msg }
 *     }
 */
@CompileDynamic
class ActorDSL {

    static ScopedValueActor<Object> actor(ActorSystem system, @DelegatesTo(ActorBuilder) Closure<?> spec) {
        def b = new ActorBuilder(system)
        spec.resolveStrategy = Closure.DELEGATE_FIRST
        spec.delegate = b
        spec()
        return b.build()
    }

    static class ActorBuilder {
        final ActorSystem system
        String name
        Closure handler
        int mailboxSize = 1000

        ActorBuilder(ActorSystem sys) { this.system = sys }

        void name(String n) { this.name = n }

        void mailbox(int size) { this.mailboxSize = size }

        void onMessage(Closure c) {
            this.handler = c
        }

        ScopedValueActor<Object> build() {
            assert name != null
            assert handler != null

            // Adapt closure → MessageHandler
            ScopedValueActor.MessageHandler<Object> h =
                    { Object msg, ScopedValueActor.ActorContext ctx ->
                        handler.call(msg, ctx)
                    } as ScopedValueActor.MessageHandler<Object>

            return system.createActor(name, h, mailboxSize)
        }
    }
}
