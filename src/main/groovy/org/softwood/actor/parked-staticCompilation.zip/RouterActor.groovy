/*
 * Copyright (c) 2025 the authors of this project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.softwood.actor

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j

import java.util.concurrent.ThreadLocalRandom
import java.util.concurrent.atomic.AtomicInteger

/**
 * Actor that routes incoming messages to a collection of routee actors
 * using a {@link RouterStrategy}.
 */
@CompileStatic
@Slf4j
class RouterActor extends ScopedValueActor<Object> {

    private final List<ScopedValueActor<?>> routees
    private final RouterStrategy strategy
    private final AtomicInteger index = new AtomicInteger(0)

    @CompileStatic
    private static final class RouteHandler
            implements ScopedValueActor.MessageHandler<Object> {

        private final RouterActor outer

        RouteHandler(RouterActor outer) {
            this.outer = outer
        }

        @Override
        Object handle(Object msg, ScopedValueActor.ActorContext ctx) {
            outer.route(msg)
            return null
        }
    }

    RouterActor(String name,
                List<ScopedValueActor<?>> routees,
                RouterStrategy strategy) {
        super(name, new RouteHandler(null), 1000)
        this.routees = routees
        this.strategy = strategy
        this.setInternalHandler(new RouteHandler(this))
    }

    RouterActor(String name,
                List<ScopedValueActor<?>> routees) {
        this(name, routees, RouterStrategy.ROUND_ROBIN)
    }

    private void route(Object msg) {
        if (routees.isEmpty()) {
            log.warn("Router '{}' has no routees for message {}", name, msg)
            return
        }
        switch (strategy) {
            case RouterStrategy.BROADCAST: broadcast(msg); break
            case RouterStrategy.RANDOM   : random(msg);    break
            case RouterStrategy.ROUND_ROBIN:
            default:                       roundRobin(msg); break
        }
    }

    private void broadcast(Object msg) {
        for (ScopedValueActor<?> a : routees) {
            ((ScopedValueActor<Object>) a).tell(msg)
        }
    }

    private void roundRobin(Object msg) {
        int i = Math.floorMod(index.getAndIncrement(), routees.size())
        ((ScopedValueActor<Object>) routees.get(i)).tell(msg)
    }

    private void random(Object msg) {
        int r = ThreadLocalRandom.current().nextInt(routees.size())
        ((ScopedValueActor<Object>) routees.get(r)).tell(msg)
    }

    List<ScopedValueActor<?>> getRoutees() {
        return Collections.unmodifiableList(routees)
    }

    RouterStrategy getStrategy() {
        return strategy
    }
}