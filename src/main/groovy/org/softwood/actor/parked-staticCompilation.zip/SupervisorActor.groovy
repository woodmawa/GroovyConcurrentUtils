/*
 * Copyright (c) 2025 the authors of this project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.softwood.actor

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j

import java.time.Duration
import java.util.concurrent.ConcurrentHashMap

/**
 * Supervisor actor that manages a set of child actors and applies a
 * {@link SupervisorStrategy} when they fail.
 */
@CompileStatic
@Slf4j
class SupervisorActor extends ScopedValueActor<Object> {

    @CompileStatic
    private static final class SupervisorHandler
            implements ScopedValueActor.MessageHandler<Object> {

        private final SupervisorActor outer

        SupervisorHandler(SupervisorActor outer) {
            this.outer = outer
        }

        @Override
        Object handle(Object msg, ScopedValueActor.ActorContext ctx) {
            return outer.handleSupervisorMessage(msg)
        }
    }

    @CompileStatic
    static final class ChildInfo {
        final String name
        final Closure<ScopedValueActor<Object>> factory
        ScopedValueActor<Object> instance

        ChildInfo(String name,
                  Closure<ScopedValueActor<Object>> factory,
                  ScopedValueActor<Object> instance) {
            this.name = name
            this.factory = factory
            this.instance = instance
        }
    }

    private final Map<String, ChildInfo> children = new ConcurrentHashMap<>()
    private SupervisorStrategy strategy = SupervisorStrategy.RESTART
    private Duration restartDelay = Duration.ofMillis(200)

    SupervisorActor(String name) {
        super(name, new SupervisorHandler(null), 1000)
        this.setInternalHandler(new SupervisorHandler(this))
    }

    void setStrategy(SupervisorStrategy s) {
        this.strategy = s
    }

    void setRestartDelay(Duration d) {
        this.restartDelay = d
    }

    ScopedValueActor<Object> supervise(String childName,
                                       Closure<ScopedValueActor<Object>> factory) {
        ScopedValueActor<Object> child = factory.call()
        ChildInfo info = new ChildInfo(childName, factory, child)
        children.put(childName, info)
        installFailureHook(info)
        return child
    }

    private void installFailureHook(ChildInfo info) {
        info.instance.setFailureListener({ Throwable t ->
            this.tell([
                    type : "failure",
                    child: info.name,
                    cause: t
            ] as Map<String, Object>)
        } as Closure<Throwable>)
    }

    private Object handleSupervisorMessage(Object msg) {
        if (!(msg instanceof Map)) {
            return null
        }
        Map m = (Map) msg
        if (m.type == "failure") {
            handleFailure((String) m.child, (Throwable) m.cause)
        }
        return null
    }

    private void handleFailure(String childName, Throwable ex) {
        ChildInfo info = children.get(childName)
        if (info == null) return

        log.warn("Supervisor '{}' saw failure in '{}': {} (strategy={})",
                name, childName, ex.message, strategy)

        switch (strategy) {
            case SupervisorStrategy.RESTART: restartChild(info); break
            case SupervisorStrategy.STOP   : stopChild(info);    break
            case SupervisorStrategy.RESUME: /* no-op */          break
            case SupervisorStrategy.ESCALATE:
                log.warn("Supervisor '{}' ESCALATE for '{}'", name, childName)
                break
        }
    }

    private void restartChild(ChildInfo info) {
        log.info("Supervisor '{}' restarting '{}' in {} ms",
                name, info.name, restartDelay.toMillis())
        try {
            info.instance.stopAndWait(restartDelay)
        } catch (Throwable ignored) {}

        ScopedValueActor<Object> newActor = info.factory.call()
        info.instance = newActor
        installFailureHook(info)
        log.info("Supervisor '{}' restarted '{}'", name, info.name)
    }

    private void stopChild(ChildInfo info) {
        log.info("Supervisor '{}' stopping child '{}'", name, info.name)
        try {
            info.instance.stopAndWait(restartDelay)
        } catch (Throwable ignored) {}
        children.remove(info.name)
    }
}
