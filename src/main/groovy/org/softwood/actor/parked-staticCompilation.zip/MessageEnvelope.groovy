/*
 * Copyright (c) 2025 the authors of this project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.softwood.actor

import groovy.transform.CompileStatic

/**
 * Lightweight wrapper representing an envelope around an actor message.
 * <p>
 * Envelopes allow attaching metadata (sender id, sequence, timestamp, headers)
 * without changing the core actor message-handling API.
 *
 * @param <M> the underlying message payload type
 */
@CompileStatic
class MessageEnvelope<M> {

    final M payload
    final String sender
    final long sequence
    final long timestamp
    final Map<String, Object> headers

    MessageEnvelope(
            M payload,
            String sender = "anonymous",
            long sequence = -1L,
            long timestamp = System.currentTimeMillis(),
            Map<String, Object> headers = Collections.emptyMap()
    ) {
        this.payload = payload
        this.sender = sender
        this.sequence = sequence
        this.timestamp = timestamp
        this.headers = headers ?: Collections.emptyMap() as Map<String, Object>
    }

    @Override
    String toString() {
        "MessageEnvelope(sender=${sender}, seq=${sequence}, ts=${timestamp}, payload=${payload})"
    }
}
